# System Monitor

Сервис мониторинга системы для Speedy Solutions.

## Описание

Этот сервис предоставляет мониторинг в реальном времени за:
- Использованием CPU
- Использованием памяти
- Использованием дискового пространства
- Сетевой активностью

## Установка

```bash
git clone https://github.com/speedy-solutions/system-monitor.git
cd system-monitor
pip install -r requirements.txt